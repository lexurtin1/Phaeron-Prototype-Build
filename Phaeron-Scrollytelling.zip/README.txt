PHAERON SCROLLYTELLING WEBSITE

1. Extract this ZIP.
2. Open Phaeron.html in Chrome, Edge, Safari or Firefox.
3. Scroll, or use the layer navigation to explore the architecture.

Phaeron.html is a self-contained offline copy. It includes the artwork,
animated Thinking Orb and straight connectors. No installation is needed.

The editable project is in source/. Its original files use JavaScript modules,
so serve source/dist/ with a local web server if working on that version.
For example, with Python installed:
  cd source/dist
  python -m http.server 8000
Then open http://localhost:8000 in your browser.

Thinking Orbs 0.3.1 is by Jakub Antalik and is MIT licensed.
Its license is included in source/dist/vendor/ and embedded in Phaeron.html.

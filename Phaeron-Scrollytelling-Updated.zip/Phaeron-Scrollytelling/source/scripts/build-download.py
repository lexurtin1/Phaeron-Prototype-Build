#!/usr/bin/env python3
"""Build the offline Phaeron artifact from the deployed static site."""
from pathlib import Path
import shutil
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
OUTPUT = Path("/workspace/scratch/d1d0f806b525/download/Phaeron-Scrollytelling.zip")


def standalone_html() -> str:
    html = (DIST / "index.html").read_text(encoding="utf-8")
    css = (DIST / "styles.css").read_text(encoding="utf-8")
    layers = (DIST / "layers.js").read_text(encoding="utf-8")
    story = (DIST / "story.js").read_text(encoding="utf-8")
    html = html.replace('<link rel="stylesheet" href="styles.css">', f"<style>\n{css}\n</style>")
    html = html.replace('<script src="layers.js" defer></script>', f"<script>\n{layers}\n</script>")
    html = html.replace('<script src="story.js" defer></script>', f"<script>\n{story}\n</script>")
    return html


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="phaeron-artifact-") as temp:
        package = Path(temp) / "Phaeron-Scrollytelling"
        source = package / "source"
        package.mkdir()
        (package / "Phaeron.html").write_text(standalone_html(), encoding="utf-8")
        (package / "README.txt").write_text(
            "PHAERON SCROLLYTELLING\n\n"
            "Open Phaeron.html in any modern browser. The complete experience works offline.\n\n"
            "Editable website files are included in source/dist.\n"
            "The visual system is generated in source/dist/layers.js.\n"
            "Layer 08 remains the provisional completion layer until its final specification is supplied.\n",
            encoding="utf-8",
        )
        shutil.copytree(DIST, source / "dist")
        shutil.copytree(ROOT / "scripts", source / "scripts")
        if (OUTPUT.exists()):
            OUTPUT.unlink()
        with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(package.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(package.parent))
    print(OUTPUT)


if __name__ == "__main__":
    main()

"""Keep one exact geometry model for the hub, ports and straight stack connectors."""
from pathlib import Path
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "dist" / "assets"
NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", NS)
DEPARTMENTS = [
    ("Commercial", 750, 420),
    ("Product", 910, 510),
    ("Operations", 910, 650),
    ("Finance", 750, 740),
    ("Engineering", 590, 650),
    ("Law", 590, 510),
]
PORTS = {name: [x, y - 25] for name, x, y in DEPARTMENTS}
CONNECTIONS = {
    "a": [
        ([331.723,365.985],"Engineering"),
        ([477.637,405.193],"Law"),
        ([580.229,192.628],"Commercial"),
        ([950.284,356.489],"Product"),
        ([1132.886,375.233],"Operations"),
        ([950.284,356.489],"Finance"),
    ],
    "b": [
        ([136.394,297.557],"Engineering"),
        ([388.562,249.227],"Law"),
        ([580.229,192.628],"Commercial"),
        ([744.667,96.099],"Commercial"),
        ([923.963,231.682],"Product"),
        ([1073.39,97.93],"Finance"),
        ([1180.528,243.766],"Operations"),
        ([1360.307,297.598],"Operations"),
    ],
}

def tag(name):
    return "{" + NS + "}" + name

def main():
    tree = ET.parse(ASSETS / "business.svg")
    root = tree.getroot()
    plate = list(root)[1]
    # The inherited plate contains the original surface, faces and softened shadow.
    for child in list(plate)[4:]:
        plate.remove(child)
    for name, x, y in DEPARTMENTS:
        dx, dy = x - 750, y - 580
        start = 1 / ((dx / 100) ** 2 + (dy / 60) ** 2) ** .5
        inset = min(80 / abs(dx) if dx else float("inf"), 25 / abs(dy) if dy else float("inf"))
        ET.SubElement(plate, tag("line"), {
            "x1": str(750 + dx * start), "y1": str(580 + dy * start),
            "x2": str(x - dx * inset), "y2": str(y - dy * inset),
            "stroke": "#008cff", "stroke-width": "2", "data-spoke": name,
        })
    ET.SubElement(plate, tag("ellipse"), {
        "cx": "750", "cy": "580", "rx": "100", "ry": "60",
        "fill": "#fff", "stroke": "#008cff", "stroke-width": "1.5",
    })
    for name, x, y in DEPARTMENTS:
        node = ET.SubElement(plate, tag("g"), {"data-department": name})
        ET.SubElement(node, tag("rect"), {
            "x": str(x-80), "y": str(y-25), "width": "160", "height": "50",
            "fill": "#fff", "stroke": "#008cff", "stroke-width": "1.3",
        })
        label = ET.SubElement(node, tag("text"), {
            "x": str(x), "y": str(y+6), "text-anchor": "middle",
            "font-family": "Arial,Helvetica,sans-serif", "font-size": "18", "fill": "#122536",
        })
        label.text = name
        ET.SubElement(node, tag("circle"), {
            "cx": str(x), "cy": str(y-25), "r": "3", "fill": "#d11945", "data-port": name,
        })
    # Normalize plate coordinates so its SVG and runtime connector coordinates are identical.
    plate.attrib.pop("transform", None)
    tree.write(ASSETS / "business.svg", encoding="unicode")
    for variant in ("a", "b"):
        tree = ET.parse(ASSETS / f"agents-{variant}.svg")
        layer = next(e for e in tree.getroot().iter() if e.get("id") == "_5-Agents_Humans")
        for child in list(layer):
            if child.tag.rsplit("}",1)[-1] in ("line", "polyline"):
                layer.remove(child)
        tree.write(ASSETS / f"agents-{variant}.svg", encoding="unicode")
    model = {
        "hubViewBox": [280,285,940,600], "agentViewBox": [-40,-25,1580,700],
        "ports": PORTS, "connections": CONNECTIONS,
    }
    (ROOT / "dist" / "hub-geometry.js").write_text("window.PhaeronHub = " + json.dumps(model) + ";\n")

if __name__ == "__main__":
    main()

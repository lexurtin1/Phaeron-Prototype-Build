PHAERON SCROLLYTELLING

Open Phaeron.html in any modern browser. The complete experience works offline.

Editable website files are included in source/dist.
The visual system is generated in source/dist/layers.js.
Layer 08 remains the provisional completion layer until its final specification is supplied.
